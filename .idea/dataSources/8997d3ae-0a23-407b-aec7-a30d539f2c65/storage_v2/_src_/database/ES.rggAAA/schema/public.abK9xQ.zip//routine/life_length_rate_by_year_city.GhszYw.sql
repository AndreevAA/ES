create function life_length_rate_by_year_city(city text)
    returns TABLE(ll numeric, cnt bigint)
    language plpgsql
as
$$
begin
    if city = 'Не указано'
        then
            return query
                select (extract(year from "depth_date") - extract(year from"birth_date")) as ll, count(extract(year from"depth_date") - extract(year from "birth_date")) as cnt from w_dir.passports where is_depth=true group by ll order by ll;
    else
        return query
            select (extract(year from "depth_date") - extract(year from"birth_date")) as ll, count(extract(year from"depth_date") - extract(year from "birth_date")) as cnt from w_dir.passports where is_depth=true and registration=city group by ll order by ll;
        end if;
end;
$$;

alter function life_length_rate_by_year_city(text) owner to postgres;

