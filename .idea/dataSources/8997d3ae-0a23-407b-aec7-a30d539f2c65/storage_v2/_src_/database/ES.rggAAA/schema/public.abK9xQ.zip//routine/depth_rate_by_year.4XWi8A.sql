create function depth_rate_by_year()
    returns TABLE(year_depth numeric, cnt bigint)
    language plpgsql
as
$$
begin
	return query
		select extract(year from "depth_date") as year_depth, count(extract(year from "depth_date")) as cnt from w_dir.passports group by year_depth order by year_depth;
end;
$$;

alter function depth_rate_by_year() owner to postgres;

