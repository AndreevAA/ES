create function delete_education(education_level_id integer) returns boolean
    language plpgsql
as
$$
declare not_passed boolean;
begin
        /* Deleting */
        delete from w_dir."EducationsLevels" where "EducationLevelID" = education_level_id;

        /* Verification */
        SELECT  ("EducationLevelID" = education_level_id) INTO not_passed
        FROM    w_dir."EducationsLevels"
        WHERE   "EducationLevelID" = education_level_id;

        RETURN not_passed;
end;
$$;

alter function delete_education(integer) owner to postgres;

