create function login_cnt(in_login text)
    returns TABLE(total bigint)
    language plpgsql
as
$$
begin
        return query
            (
                select count(*) from inner_s.users where login = in_login
            );
        end
$$;

alter function login_cnt(text) owner to postgres;

