create function update_user(id_i integer, login_i text, password_i text, acs_level_i integer) returns boolean
    language plpgsql
as
$$
begin
        update inner_s.users
               SET login = login_i,
                   password = password_i,
                   acs_level  = acs_level_i
             WHERE id = id_i;
            RETURN FOUND;
        end;
$$;

alter function update_user(integer, text, text, integer) owner to postgres;

