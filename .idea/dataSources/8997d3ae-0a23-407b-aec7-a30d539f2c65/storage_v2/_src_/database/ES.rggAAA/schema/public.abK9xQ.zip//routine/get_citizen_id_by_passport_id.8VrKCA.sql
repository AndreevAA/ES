create function get_citizen_id_by_passport_id(passport_id integer) returns integer
    language plpgsql
as
$$
declare citizen_id_found boolean;
    begin
        select "CitizenID" into citizen_id_found from w_dir."Citizens" where "passportID"=passport_id;
        
        return citizen_id_found;
    end;
$$;

alter function get_citizen_id_by_passport_id(integer) owner to postgres;

