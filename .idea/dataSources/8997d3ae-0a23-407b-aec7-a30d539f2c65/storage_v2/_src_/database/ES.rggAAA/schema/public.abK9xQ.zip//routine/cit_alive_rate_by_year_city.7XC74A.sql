create function cit_alive_rate_by_year_city(city text)
    returns TABLE(year_birth numeric, cnt bigint)
    language plpgsql
as
$$
begin

    if city = 'Не указано' then
            return query
                select extract(year from "birth_date") as year_birth, count(extract(year from "birth_date")) as cnt from w_dir.passports group by year_birth order by year_birth;
        else
            return query
              select extract(year from "birth_date") as year_birth, count(extract(year from "birth_date")) as cnt from w_dir.passports where "is_depth"=false and registration=city group by year_birth order by year_birth;
    end if;
end;
$$;

alter function cit_alive_rate_by_year_city(text) owner to postgres;

