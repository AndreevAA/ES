create function is_update_user_available(id_i integer, login_i text, password_i text)
    returns TABLE(id_t integer)
    language plpgsql
as
$$
begin
            return query select id as id_t from inner_s.users where id = id_i or login = login_i or password = password_i;
        end;
$$;

alter function is_update_user_available(integer, text, text) owner to postgres;

