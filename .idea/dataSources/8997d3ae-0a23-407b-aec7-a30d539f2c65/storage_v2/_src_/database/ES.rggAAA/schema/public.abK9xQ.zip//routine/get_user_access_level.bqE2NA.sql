create function get_user_access_level(usr_id integer, usr_login text)
    returns TABLE(acs_l integer, u_id integer)
    language plpgsql
as
$$
begin
    return query
                select acs_level as acs_l, id as u_id from inner_s.users where id = usr_id and login = usr_login;
end;
$$;

alter function get_user_access_level(integer, text) owner to postgres;

