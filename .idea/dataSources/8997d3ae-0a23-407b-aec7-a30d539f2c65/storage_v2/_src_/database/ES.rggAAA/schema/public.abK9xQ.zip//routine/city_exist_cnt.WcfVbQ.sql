create function city_exist_cnt(city text)
    returns TABLE(cnt bigint)
    language plpgsql
as
$$
begin
            return query
                select count(registration) from w_dir.passports where registration=city;
            end
$$;

alter function city_exist_cnt(text) owner to postgres;

