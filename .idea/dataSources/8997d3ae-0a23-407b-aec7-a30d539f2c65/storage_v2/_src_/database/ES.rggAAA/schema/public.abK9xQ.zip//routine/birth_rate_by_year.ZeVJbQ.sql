create function birth_rate_by_year()
    returns TABLE(year_birth numeric, cnt bigint)
    language plpgsql
as
$$
begin
	return query
		select extract(year from "birth_date") as year_birth, count(extract(year from "birth_date")) as cnt from w_dir.passports group by year_birth order by year_birth;
end;
$$;

alter function birth_rate_by_year() owner to postgres;

