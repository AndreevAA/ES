create function create_user(id_i integer, login_i text, password_i text, acs_level_i integer) returns boolean
    language plpgsql
as
$$
begin
        insert into inner_s.users (id, login, password, acs_level) values (id_i, login_i, password_i, acs_level_i);
        return FOUND;
        end;
$$;

alter function create_user(integer, text, text, integer) owner to postgres;

