create function max_id()
    returns TABLE(total integer)
    language plpgsql
as
$$
begin
        return query
            (select MAX("id") from inner_s.users);
        end
$$;

alter function max_id() owner to postgres;

