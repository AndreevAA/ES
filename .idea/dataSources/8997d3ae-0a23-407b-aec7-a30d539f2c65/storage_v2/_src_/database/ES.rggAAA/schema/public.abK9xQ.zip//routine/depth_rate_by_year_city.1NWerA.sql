create function depth_rate_by_year_city(city text)
    returns TABLE(year_depth numeric, cnt bigint)
    language plpgsql
as
$$
begin
    if city = 'Не указано' then
        return query
            select extract(year from "depth_date") as year_depth, count(extract(year from "depth_date")) as cnt from w_dir.passports where is_depth=true group by year_depth order by year_depth;
    else
        return query
            select extract(year from "depth_date") as year_depth, count(extract(year from "depth_date")) as cnt from w_dir.passports where is_depth=true and registration=city group by year_depth order by year_depth;
    end if;
end;
$$;

alter function depth_rate_by_year_city(text) owner to postgres;

