create function delete_citizen(citizen_id integer) returns boolean
    language plpgsql
as
$$
declare not_passed boolean;
begin
        /* Deleting */
        delete from w_dir."Citizens" where "CitizenID" = citizen_id;

        /* Verification */
        SELECT  ("CitizenID" = citizen_id) INTO not_passed
        FROM    w_dir."Citizens"
        WHERE   "CitizenID" = citizen_id;

        RETURN not_passed;
end;
$$;

alter function delete_citizen(integer) owner to postgres;

